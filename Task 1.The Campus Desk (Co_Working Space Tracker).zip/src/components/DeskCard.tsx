import React, { useEffect, useState } from 'react';
import { Desk } from '../types';
import { 
  Clock, 
  User, 
  Zap, 
  Sun, 
  Monitor, 
  VolumeX, 
  Armchair, 
  CheckCircle2, 
  LogOut, 
  TimerReset,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface DeskCardProps {
  desk: Desk;
  onCheckIn: (desk: Desk) => void;
  onCheckOut: (deskId: string) => void;
}

export const DeskCard: React.FC<DeskCardProps> = ({
  desk,
  onCheckIn,
  onCheckOut,
}) => {
  const [remainingSec, setRemainingSec] = useState<number | null>(null);

  // Live Timer countdown logic
  useEffect(() => {
    if (desk.status !== 'occupied' || !desk.expiresAt) {
      setRemainingSec(null);
      return;
    }

    const updateTimer = () => {
      const diffMs = (desk.expiresAt || 0) - Date.now();
      if (diffMs <= 0) {
        setRemainingSec(0);
      } else {
        setRemainingSec(Math.floor(diffMs / 1000));
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [desk.status, desk.expiresAt]);

  const formatTime = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) {
      return `${h}h ${m}m ${s}s`;
    }
    return `${m}m ${s}s`;
  };

  const amenityIcons: Record<string, { icon: any; label: string }> = {
    power: { icon: Zap, label: 'Power Outlet' },
    window: { icon: Sun, label: 'Window View' },
    monitor: { icon: Monitor, label: 'Monitor' },
    silent: { icon: VolumeX, label: 'Silent' },
    ergo: { icon: Armchair, label: 'Ergo Chair' },
  };

  const isOccupied = desk.status === 'occupied';
  const isAvailable = desk.status === 'available';
  const isReserved = desk.status === 'reserved';

  return (
    <article
      id={`desk-station-${desk.code.toLowerCase()}`}
      aria-labelledby={`desk-name-${desk.id}`}
      className={`rounded-2xl border-2 transition-all duration-300 flex flex-col justify-between shadow-sm relative overflow-hidden group ${
        isAvailable
          ? 'bg-white border-emerald-300 hover:border-emerald-500 hover:shadow-md'
          : isOccupied
          ? 'bg-slate-50 border-rose-300 hover:border-rose-400'
          : 'bg-amber-50/60 border-amber-300'
      }`}
    >
      {/* Top Status Accent Line */}
      <div
        className={`h-2 w-full ${
          isAvailable ? 'bg-emerald-500' : isOccupied ? 'bg-rose-500' : 'bg-amber-500'
        }`}
      />

      <div className="p-5 flex-1 flex flex-col">
        
        {/* Header: Code Badge & Floor/Zone */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-[#F2F0EA] font-mono font-bold text-xs tracking-wider shadow-sm">
              {desk.code}
            </span>
            <span className="text-xs font-semibold text-slate-500 font-mono">
              {desk.floor} Floor
            </span>
          </div>

          {/* Status Chip */}
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider font-mono flex items-center gap-1.5 ${
              isAvailable
                ? 'bg-emerald-100 text-emerald-800'
                : isOccupied
                ? 'bg-rose-100 text-rose-800'
                : 'bg-amber-100 text-amber-800'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isAvailable ? 'bg-emerald-500 animate-pulse' : isOccupied ? 'bg-rose-500' : 'bg-amber-500'
              }`}
            />
            {desk.status}
          </span>
        </div>

        {/* Headline (Montserrat Typography Mandate) */}
        <h3
          id={`desk-name-${desk.id}`}
          className="fluid-h3 text-slate-900 mt-3 font-['Montserrat'] font-bold tracking-tight group-hover:text-[#A5856F] transition-colors"
        >
          {desk.name}
        </h3>

        <div className="text-xs text-slate-500 mt-1 font-medium">
          Sector: <span className="text-slate-700 font-semibold">{desk.zone}</span>
        </div>

        {desk.notes && (
          <p className="text-xs text-slate-500 italic mt-2 bg-slate-100/80 p-2 rounded-lg">
            "{desk.notes}"
          </p>
        )}

        {/* Amenities Icons */}
        <div className="mt-4 flex flex-wrap gap-1.5">
          {desk.amenities.map((am) => {
            const config = amenityIcons[am];
            if (!config) return null;
            const Icon = config.icon;
            return (
              <span
                key={am}
                title={config.label}
                className="px-2 py-1 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium flex items-center gap-1 border border-slate-200"
              >
                <Icon className="w-3 h-3 text-[#A5856F]" />
                <span>{config.label}</span>
              </span>
            );
          })}
        </div>

        {/* Occupant & Timer Section (Inter Body Mandate for Timer) */}
        {isOccupied && (
          <div className="mt-5 p-3.5 bg-rose-50/80 border border-rose-200 rounded-xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-rose-950 truncate">
              <User className="w-4 h-4 text-rose-600 shrink-0" />
              <span className="truncate">{desk.occupiedBy || 'Anonymous Co-Worker'}</span>
            </div>

            {remainingSec !== null && (
              <div className="mt-2 pt-2 border-t border-rose-200/60 flex items-center justify-between text-xs font-['Inter']">
                <span className="text-rose-700 flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
                  Timer Left:
                </span>
                <span className={`font-mono font-bold text-sm ${remainingSec < 300 ? 'text-rose-600 animate-pulse font-extrabold' : 'text-slate-900'}`}>
                  {remainingSec <= 0 ? 'Expired (Overdue)' : formatTime(remainingSec)}
                </span>
              </div>
            )}
          </div>
        )}

      </div>

      {/* Footer Actions */}
      <div className="p-4 bg-slate-50/80 border-t border-slate-200 flex items-center justify-between gap-2">
        {isAvailable ? (
          <button
            onClick={() => onCheckIn(desk)}
            className="w-full py-2.5 px-4 bg-[#1e293b] hover:bg-[#A5856F] text-white font-['Montserrat'] font-bold text-sm rounded-xl transition-all shadow-sm hover:shadow flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 text-[#A0D4E0]" />
            <span>Check-in &amp; Set Timer</span>
          </button>
        ) : isOccupied ? (
          <button
            onClick={() => onCheckOut(desk.id)}
            className="w-full py-2.5 px-4 bg-white hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-300 font-['Montserrat'] font-bold text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 group/btn"
          >
            <LogOut className="w-4 h-4 text-rose-500 group-hover/btn:text-white transition-colors" />
            <span>Release Desk</span>
          </button>
        ) : (
          <div className="w-full text-center py-2 text-xs text-amber-800 font-semibold flex items-center justify-center gap-1.5">
            <AlertCircle className="w-4 h-4" /> Reserved for Event
          </div>
        )}
      </div>
    </article>
  );
};
