import React from 'react';
import { Compass, ShieldCheck, Heart, Terminal, MapPin, Mail, Phone, Globe } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer id="campus-footer" aria-label="Terminal metadata and building credentials" className="bg-[#1e293b] text-[#F2F0EA] border-t-4 border-[#A5856F] pt-12 pb-8 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-700">
          
          {/* Col 1: System Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-[#A0D4E0] text-[#1e293b] rounded-xl font-bold">
                <Compass className="w-5 h-5" />
              </div>
              <span className="font-['Montserrat'] font-extrabold text-lg tracking-tight text-white">
                Campus Desk
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed font-['Inter']">
              Project 2: Co-Working Space Tracker &amp; Thermal Density Heatmap. Built using pure responsive architecture without CSS frameworks or UI slop.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono text-[#A0D4E0]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
              <span>System Core: Active &amp; Synchronized</span>
            </div>
          </div>

          {/* Col 2: Semantic Mandate Reference */}
          <div className="space-y-2 text-xs font-['Inter']">
            <h4 className="font-['Montserrat'] font-bold text-sm text-[#A0D4E0] uppercase tracking-wider font-mono">
              Architecture Pillars
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>Pillar 1: Empathy Map Blueprint</span>
              </li>
              <li className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>Pillar 2: Warm 2025 Aesthetics</span>
              </li>
              <li className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>Pillar 3: Semantic Integrity &amp; Clamp()</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Building Operations */}
          <div className="space-y-2 text-xs font-['Inter']">
            <h4 className="font-['Montserrat'] font-bold text-sm text-[#A0D4E0] uppercase tracking-wider font-mono">
              Building Operations
            </h4>
            <div className="text-slate-400 space-y-1">
              <div>Ground Floor: 24/7 Library Access</div>
              <div>1st Floor: 08:00 AM – 10:00 PM</div>
              <div>2nd Floor Quiet Archive: 09:00 AM – 08:00 PM</div>
            </div>
            <div className="pt-2 text-amber-300 font-mono text-[11px]">
              ⚡ Auto-release triggered at timer expiration.
            </div>
          </div>

          {/* Col 4: Training Kit Credit */}
          <div className="space-y-2 text-xs font-['Inter']">
            <h4 className="font-['Montserrat'] font-bold text-sm text-[#A0D4E0] uppercase tracking-wider font-mono">
              DecodeLabs Batch 2026
            </h4>
            <div className="space-y-1.5 text-slate-400">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>+91 89330 06408</span>
              </div>
              <div className="flex items-center gap-2 truncate">
                <Mail className="w-3.5 h-3.5 text-[#A5856F] shrink-0" />
                <span className="truncate">decodelabs.tech@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>Greater Lucknow, India</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500">
          <div>
            &copy; 2026 DecodeLabs Industrial Training Kit — Full Stack Development Project 1/2.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span className="hover:text-white cursor-pointer">WCAG 2.1 Compliant</span>
            <span>&bull;</span>
            <span className="hover:text-white cursor-pointer">Mobile-First</span>
            <span>&bull;</span>
            <span className="hover:text-white cursor-pointer">Semantic HTML5</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
