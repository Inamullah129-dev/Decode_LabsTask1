import React from 'react';
import { Desk, Zone } from '../types';
import { Flame, ShieldCheck, Users, Sparkles, MapPin } from 'lucide-react';

interface HeatmapStatsProps {
  desks: Desk[];
  onSelectZone: (zone: Zone | 'all') => void;
  activeZone: Zone | 'all';
}

export const HeatmapStats: React.FC<HeatmapStatsProps> = ({
  desks,
  onSelectZone,
  activeZone,
}) => {
  const zoneList: Zone[] = ['Quiet Zone', 'Collaboration Zone', 'Window View Gallery', 'Focus Booths'];

  return (
    <section id="building-crowd-heatmap" aria-labelledby="heatmap-title" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 id="heatmap-title" className="fluid-h2 text-slate-800 flex items-center gap-2">
            <Flame className="w-6 h-6 text-rose-500 fill-rose-500 animate-bounce" />
            <span>Building Zone Heatmap</span>
          </h2>
          <p className="fluid-body text-slate-600 text-sm mt-0.5">
            Real-time thermal density analysis across co-working sectors. Click a zone to filter desks.
          </p>
        </div>

        {/* Legend */}
        <div className="hidden sm:flex items-center gap-4 text-xs font-mono bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm">
          <span className="flex items-center gap-1.5 text-emerald-700 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> &lt;50% Free
          </span>
          <span className="flex items-center gap-1.5 text-amber-700 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> 50-80% Moderate
          </span>
          <span className="flex items-center gap-1.5 text-rose-700 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> &gt;80% Crowded
          </span>
        </div>
      </div>

      {/* 4 Cards Grid for Zones */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {zoneList.map((z) => {
          const zoneDesks = desks.filter((d) => d.zone === z);
          const total = zoneDesks.length;
          const occupied = zoneDesks.filter((d) => d.status === 'occupied' || d.status === 'reserved').length;
          const free = total - occupied;
          const percent = total ? Math.round((occupied / total) * 100) : 0;

          const isCrowded = percent >= 80;
          const isModerate = percent >= 50 && percent < 80;
          const isFree = percent < 50;

          const active = activeZone === z;

          return (
            <div
              key={z}
              id={`zone-card-${z.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => onSelectZone(active ? 'all' : z)}
              className={`p-5 rounded-2xl cursor-pointer transition-all border-2 relative overflow-hidden group ${
                active
                  ? 'border-[#1e293b] bg-white shadow-lg ring-4 ring-[#A0D4E0]/40 transform -translate-y-1'
                  : 'border-slate-200 bg-white/80 hover:bg-white hover:border-slate-300 shadow-sm hover:shadow-md'
              }`}
            >
              {/* Heat Indicator Top Stripe */}
              <div
                className={`absolute top-0 left-0 right-0 h-1.5 transition-colors ${
                  isCrowded ? 'bg-rose-500' : isModerate ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
              />

              <div className="flex items-start justify-between gap-2 mt-1">
                <div>
                  <span className="text-xs font-mono text-slate-500 uppercase tracking-wider block">
                    Sector Profile
                  </span>
                  <h3 className="font-['Montserrat'] font-bold text-base text-slate-800 group-hover:text-[#A5856F] transition-colors">
                    {z}
                  </h3>
                </div>
                <span
                  className={`px-2 py-1 rounded-lg text-xs font-mono font-bold shrink-0 ${
                    isCrowded
                      ? 'bg-rose-100 text-rose-800'
                      : isModerate
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {isCrowded ? 'Crowded' : isModerate ? 'Moderate' : 'Quiet Spot'}
                </span>
              </div>

              {/* Progress Bar Heatmap */}
              <div className="mt-4">
                <div className="flex justify-between text-xs font-medium text-slate-600 mb-1 font-mono">
                  <span>Occupancy: {percent}%</span>
                  <span className="font-bold text-slate-900">{free} available</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden p-0.5">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${
                      isCrowded ? 'bg-rose-500' : isModerate ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100">
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  {occupied} Checked in
                </span>
                <span className="text-[#A5856F] font-semibold text-[11px] group-hover:underline">
                  {active ? 'Showing Only' : 'Filter Sector →'}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
