import React from 'react';
import { Compass, Clock, ShieldCheck, Search } from 'lucide-react';

interface HeaderProps {
  totalDesks: number;
  availableDesks: number;
  search: string;
  onSearchChange: (val: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalDesks,
  availableDesks,
  search,
  onSearchChange,
}) => {
  const occupancyPercent = Math.round(((totalDesks - availableDesks) / (totalDesks || 1)) * 100);

  return (
    <header id="campus-header" className="bg-[#1e293b] text-[#F2F0EA] shadow-xl border-b-4 border-[#A5856F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          
          {/* Brand & Wayfinding */}
          <div className="flex items-start sm:items-center gap-4">
            <div className="p-3.5 bg-[#A0D4E0] text-[#1e293b] rounded-2xl shadow-md flex items-center justify-center shrink-0">
              <Compass className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider bg-[#A5856F] text-white font-mono">
                  Real-time Wayfinding
                </span>
                <span className="flex items-center gap-1 text-xs text-[#A0D4E0] font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping" />
                  Live Heatmap
                </span>
              </div>
              <h1 className="fluid-h1 text-[#F2F0EA] mt-1 tracking-tight">
                Campus Desk
              </h1>
              <p className="fluid-body text-[#A0D4E0] text-opacity-90 max-w-xl mt-1">
                Co-working space & university library tracker. Locate quiet window seats, power outlets, and reserve available desks instantly.
              </p>
            </div>
          </div>

          {/* Quick Stats & Search Right */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            
            {/* Occupancy Heat Badge */}
            <div className="bg-[#0f172a] px-4 py-3 rounded-2xl border border-slate-700 flex items-center gap-3">
              <div className="relative flex items-center justify-center">
                <svg className="w-12 h-12 transform -rotate-90">
                  <circle
                    cx="24"
                    cy="24"
                    r="18"
                    stroke="currentColor"
                    strokeWidth="4"
                    className="text-slate-800"
                    fill="none"
                  />
                  <circle
                    cx="24"
                    cy="24"
                    r="18"
                    stroke={occupancyPercent > 80 ? '#f43f5e' : occupancyPercent > 50 ? '#f59e0b' : '#10b981'}
                    strokeWidth="4"
                    strokeDasharray={113}
                    strokeDashoffset={113 - (113 * occupancyPercent) / 100}
                    strokeLinecap="round"
                    fill="none"
                    className="transition-all duration-700"
                  />
                </svg>
                <span className="absolute text-xs font-bold font-mono text-white">
                  {occupancyPercent}%
                </span>
              </div>
              <div>
                <div className="text-xs text-slate-400 font-medium">Building Load</div>
                <div className="text-sm font-bold text-white flex items-center gap-1.5 font-['Montserrat']">
                  <span className={occupancyPercent > 80 ? 'text-rose-400' : 'text-emerald-400'}>
                    {availableDesks} Free
                  </span>
                  <span className="text-slate-500">/</span>
                  <span>{totalDesks} Desks</span>
                </div>
              </div>
            </div>

            {/* Quick Search Input */}
            <div className="relative min-w-[240px]">
              <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                id="header-desk-search"
                type="text"
                placeholder="Search desk name, G-01..."
                value={search}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full bg-[#0f172a] text-[#F2F0EA] pl-10 pr-4 py-3 rounded-xl border border-slate-700 focus:outline-none focus:border-[#A0D4E0] text-sm transition placeholder:text-slate-500"
              />
              {search && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};
