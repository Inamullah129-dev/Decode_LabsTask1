import React, { useState } from 'react';
import { Desk } from '../types';
import { Clock, User, Sparkles, CheckCircle2, X, Armchair } from 'lucide-react';

interface CheckInModalProps {
  desk: Desk | null;
  onClose: () => void;
  onConfirm: (deskId: string, userName: string, durationMin: number, notes?: string) => void;
}

export const CheckInModal: React.FC<CheckInModalProps> = ({
  desk,
  onClose,
  onConfirm,
}) => {
  const [userName, setUserName] = useState('');
  const [durationMin, setDurationMin] = useState<number>(60); // default 1 hr
  const [customNotes, setCustomNotes] = useState('');

  if (!desk) return null;

  const timerPresets = [
    { label: '30 Minutes', min: 30 },
    { label: '1 Hour', min: 60 },
    { label: '2 Hours', min: 120 },
    { label: '4 Hours', min: 240 },
    { label: 'Full Day (8h)', min: 480 },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nameToUse = userName.trim() || 'Anonymous Campus Member';
    onConfirm(desk.id, nameToUse, durationMin, customNotes.trim() || undefined);
  };

  return (
    <div
      id="check-in-modal-backdrop"
      className="fixed inset-0 z-50 bg-[#0f172a]/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in"
    >
      <div
        id="check-in-dialog"
        role="dialog"
        aria-labelledby="modal-desk-title"
        aria-modal="true"
        className="bg-[#F2F0EA] rounded-3xl max-w-lg w-full shadow-2xl border-4 border-[#A5856F] overflow-hidden transform transition-all animate-scale-up"
      >
        {/* Modal Header */}
        <div className="bg-[#1e293b] text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#A0D4E0] text-[#1e293b] rounded-xl font-mono font-bold text-sm">
              {desk.code}
            </div>
            <div>
              <span className="text-xs font-mono text-[#A0D4E0] block uppercase tracking-wider">
                Desk Check-in Protocol
              </span>
              <h2 id="modal-desk-title" className="font-['Montserrat'] font-bold text-xl tracking-tight">
                {desk.name}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="p-2 rounded-full hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 font-['Inter']">
          
          {/* Desk Summary Banner */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between text-xs text-slate-600">
            <div>
              <span className="font-semibold text-slate-900 block">Sector: {desk.zone}</span>
              <span>Floor: {desk.floor} Floor</span>
            </div>
            <div className="flex gap-1">
              {desk.amenities.map((a) => (
                <span key={a} className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[10px] uppercase font-bold border border-slate-200">
                  {a}
                </span>
              ))}
            </div>
          </div>

          {/* User Name & Department */}
          <div>
            <label htmlFor="checkin-user-name" className="block text-sm font-bold text-slate-800 mb-1.5 font-['Montserrat'] flex items-center gap-2">
              <User className="w-4 h-4 text-[#A5856F]" />
              <span>Your Name or Role <span className="text-slate-400 font-normal">(Optional)</span></span>
            </label>
            <input
              id="checkin-user-name"
              type="text"
              placeholder="e.g. Alex M. (Computer Science Student)"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="w-full bg-white px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:border-[#A5856F] focus:ring-2 focus:ring-[#A5856F]/20 text-sm transition shadow-sm placeholder:text-slate-400"
            />
          </div>

          {/* Timer Duration Picker (Inter Body Font for Timer) */}
          <div>
            <label className="block text-sm font-bold text-slate-800 mb-2 font-['Montserrat'] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#A5856F]" />
              <span>Set Co-Working Timer Duration</span>
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {timerPresets.map((preset) => {
                const active = durationMin === preset.min;
                return (
                  <button
                    key={preset.min}
                    type="button"
                    onClick={() => setDurationMin(preset.min)}
                    className={`py-2.5 px-2 rounded-xl text-xs font-mono font-bold transition flex flex-col items-center justify-center border ${
                      active
                        ? 'bg-[#A5856F] text-white border-[#A5856F] shadow-md transform scale-105'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <span>{preset.min >= 60 ? `${preset.min / 60} hr` : `${preset.min} m`}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notes Optional */}
          <div>
            <label htmlFor="checkin-notes" className="block text-xs font-semibold text-slate-600 mb-1">
              Custom Status Note (e.g. "On Zoom call until 2 PM")
            </label>
            <input
              id="checkin-notes"
              type="text"
              placeholder="Add optional note visible to others..."
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              className="w-full bg-white px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-[#A5856F] text-xs transition placeholder:text-slate-400"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-300 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 rounded-xl font-semibold text-sm text-slate-600 hover:bg-slate-200 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-[#1e293b] hover:bg-[#A5856F] text-white font-['Montserrat'] font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2"
            >
              <CheckCircle2 className="w-5 h-5 text-[#A0D4E0]" />
              <span>Confirm Check-in</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
