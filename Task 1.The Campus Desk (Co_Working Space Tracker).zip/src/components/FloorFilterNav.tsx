import React from 'react';
import { Floor, Zone, FilterState } from '../types';
import { Layers, Filter, Zap, Sun, Monitor, VolumeX, Armchair, CheckCircle2 } from 'lucide-react';

interface FloorFilterNavProps {
  filter: FilterState;
  onFilterChange: (newFilter: Partial<FilterState>) => void;
  floorCounts: Record<Floor | 'all', { total: number; available: number }>;
}

export const FloorFilterNav: React.FC<FloorFilterNavProps> = ({
  filter,
  onFilterChange,
  floorCounts,
}) => {
  const floors: (Floor | 'all')[] = ['all', 'Ground', '1st', '2nd'];
  const zones: (Zone | 'all')[] = ['all', 'Quiet Zone', 'Collaboration Zone', 'Window View Gallery', 'Focus Booths'];

  const amenities = [
    { id: 'power', label: 'Power Outlet', icon: Zap },
    { id: 'window', label: 'Window View', icon: Sun },
    { id: 'monitor', label: 'Dual Monitor', icon: Monitor },
    { id: 'silent', label: 'Silent Enclave', icon: VolumeX },
    { id: 'ergo', label: 'Ergo Chair', icon: Armchair },
  ];

  return (
    <nav id="floor-wayfinder-nav" aria-label="Floor and Zone Navigation" className="bg-[#F2F0EA] border-b border-slate-300 shadow-sm sticky top-0 z-30 transition-all backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        
        {/* Top Row: Floor Switcher (Primary Wayfinding) */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 mr-1 shrink-0 font-mono">
              <Layers className="w-4 h-4 text-[#A5856F]" />
              Select Floor:
            </span>

            {floors.map((fl) => {
              const active = filter.floor === fl;
              const stats = floorCounts[fl] || { total: 0, available: 0 };
              
              return (
                <button
                  key={fl}
                  id={`nav-floor-${fl}`}
                  onClick={() => onFilterChange({ floor: fl })}
                  className={`px-4 py-2.5 rounded-xl font-medium text-sm transition-all flex items-center gap-2 shrink-0 ${
                    active
                      ? 'bg-[#A5856F] text-white shadow-md transform scale-[1.02]'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  <span className="font-['Montserrat'] font-bold">
                    {fl === 'all' ? 'All Floors' : `${fl} Floor`}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-mono ${
                      active ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {stats.available}/{stats.total} free
                  </span>
                </button>
              );
            })}
          </div>

          {/* Availability Quick Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              id="nav-filter-available-only"
              onClick={() => onFilterChange({ onlyAvailable: !filter.onlyAvailable })}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition flex items-center gap-2 border ${
                filter.onlyAvailable
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
              }`}
            >
              <CheckCircle2 className={`w-4 h-4 ${filter.onlyAvailable ? 'text-white' : 'text-emerald-600'}`} />
              <span>Available Only</span>
            </button>
          </div>

        </div>

        {/* Bottom Row: Zone Type Filters & Amenities */}
        <div className="mt-3 pt-3 border-t border-slate-200 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          
          {/* Zone Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-semibold text-slate-500 mr-1 shrink-0 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Zone:
            </span>
            {zones.map((zn) => {
              const active = filter.zone === zn;
              return (
                <button
                  key={zn}
                  onClick={() => onFilterChange({ zone: zn })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 ${
                    active
                      ? 'bg-[#1e293b] text-[#A0D4E0] shadow-sm'
                      : 'bg-slate-200/70 text-slate-700 hover:bg-slate-300/80'
                  }`}
                >
                  {zn === 'all' ? 'All Zones' : zn}
                </button>
              );
            })}
          </div>

          {/* Amenity Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-semibold text-slate-500 mr-1 shrink-0">Amenity:</span>
            <button
              onClick={() => onFilterChange({ amenity: 'all' })}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition ${
                filter.amenity === 'all' ? 'bg-[#A0D4E0] text-[#1e293b] font-bold' : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              Any
            </button>
            {amenities.map((item) => {
              const IconComp = item.icon;
              const active = filter.amenity === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onFilterChange({ amenity: active ? 'all' : item.id })}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium transition flex items-center gap-1 shrink-0 ${
                    active
                      ? 'bg-[#A5856F] text-white shadow-sm font-bold'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  <IconComp className="w-3 h-3" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

        </div>

      </div>
    </nav>
  );
};
