export type Floor = 'Ground' | '1st' | '2nd';

export type Zone = 'Quiet Zone' | 'Collaboration Zone' | 'Window View Gallery' | 'Focus Booths';

export interface Amenity {
  id: string;
  label: string;
  icon: string; // lucide icon name
}

export type DeskStatus = 'available' | 'occupied' | 'reserved';

export interface Desk {
  id: string;
  name: string;
  code: string; // e.g. "G-01", "1-04"
  floor: Floor;
  zone: Zone;
  status: DeskStatus;
  amenities: string[]; // e.g. ['power', 'window', 'monitor', 'silent']
  occupiedBy?: string;
  checkInTime?: number; // timestamp ms
  timerDuration?: number; // duration ms
  expiresAt?: number; // timestamp ms
  notes?: string;
}

export interface FilterState {
  floor: Floor | 'all';
  zone: Zone | 'all';
  search: string;
  onlyAvailable: boolean;
  amenity: string | 'all';
}
