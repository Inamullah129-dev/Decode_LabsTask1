import React, { useState, useMemo, useEffect } from 'react';
import { Desk, FilterState, Floor, Zone } from './types';
import { INITIAL_DESKS } from './data';
import { Header } from './components/Header';
import { FloorFilterNav } from './components/FloorFilterNav';
import { HeatmapStats } from './components/HeatmapStats';
import { DeskCard } from './components/DeskCard';
import { CheckInModal } from './components/CheckInModal';
import { Footer } from './components/Footer';
import { Search, SlidersHorizontal, Sparkles, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [desks, setDesks] = useState<Desk[]>(INITIAL_DESKS);
  const [filter, setFilter] = useState<FilterState>({
    floor: 'all',
    zone: 'all',
    search: '',
    onlyAvailable: false,
    amenity: 'all',
  });

  const [activeCheckInDesk, setActiveCheckInDesk] = useState<Desk | null>(null);

  // Periodically check for expired timers and auto-release them
  useEffect(() => {
    const timerCheckInterval = setInterval(() => {
      const now = Date.now();
      setDesks((prev) =>
        prev.map((d) => {
          if (d.status === 'occupied' && d.expiresAt && now >= d.expiresAt + 60000) {
            // Auto release after 1 min overdue
            return {
              ...d,
              status: 'available',
              occupiedBy: undefined,
              checkInTime: undefined,
              timerDuration: undefined,
              expiresAt: undefined,
              notes: undefined,
            };
          }
          return d;
        })
      );
    }, 15000);

    return () => clearInterval(timerCheckInterval);
  }, []);

  const handleFilterChange = (newFilter: Partial<FilterState>) => {
    setFilter((prev) => ({ ...prev, ...newFilter }));
  };

  // Calculate stats for Header & Nav
  const floorCounts = useMemo(() => {
    const counts: Record<Floor | 'all', { total: number; available: number }> = {
      all: { total: 0, available: 0 },
      Ground: { total: 0, available: 0 },
      '1st': { total: 0, available: 0 },
      '2nd': { total: 0, available: 0 },
    };

    desks.forEach((d) => {
      counts.all.total += 1;
      counts[d.floor].total += 1;
      if (d.status === 'available') {
        counts.all.available += 1;
        counts[d.floor].available += 1;
      }
    });

    return counts;
  }, [desks]);

  // Filtered Desks list
  const filteredDesks = useMemo(() => {
    return desks.filter((d) => {
      // Floor filter
      if (filter.floor !== 'all' && d.floor !== filter.floor) return false;
      
      // Zone filter
      if (filter.zone !== 'all' && d.zone !== filter.zone) return false;
      
      // Available only toggle
      if (filter.onlyAvailable && d.status !== 'available') return false;
      
      // Amenity filter
      if (filter.amenity !== 'all' && !d.amenities.includes(filter.amenity)) return false;
      
      // Search text query
      if (filter.search.trim()) {
        const q = filter.search.toLowerCase().trim();
        const matchName = d.name.toLowerCase().includes(q);
        const matchCode = d.code.toLowerCase().includes(q);
        const matchUser = d.occupiedBy?.toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchUser) return false;
      }

      return true;
    });
  }, [desks, filter]);

  // Check-in confirmation handler
  const handleConfirmCheckin = (
    deskId: string,
    userName: string,
    durationMin: number,
    notes?: string
  ) => {
    const now = Date.now();
    const durationMs = durationMin * 60 * 1000;

    setDesks((prev) =>
      prev.map((d) => {
        if (d.id === deskId) {
          return {
            ...d,
            status: 'occupied',
            occupiedBy: userName,
            checkInTime: now,
            timerDuration: durationMs,
            expiresAt: now + durationMs,
            notes: notes || d.notes,
          };
        }
        return d;
      })
    );

    setActiveCheckInDesk(null);
  };

  // Check-out / Release desk handler
  const handleReleaseDesk = (deskId: string) => {
    setDesks((prev) =>
      prev.map((d) => {
        if (d.id === deskId) {
          return {
            ...d,
            status: 'available',
            occupiedBy: undefined,
            checkInTime: undefined,
            timerDuration: undefined,
            expiresAt: undefined,
            notes: undefined,
          };
        }
        return d;
      })
    );
  };

  const handleResetFilters = () => {
    setFilter({
      floor: 'all',
      zone: 'all',
      search: '',
      onlyAvailable: false,
      amenity: 'all',
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F2F0EA] text-slate-800 font-['Inter'] selection:bg-[#A0D4E0] selection:text-slate-900">
      
      {/* Semantic <header> */}
      <Header
        totalDesks={floorCounts.all.total}
        availableDesks={floorCounts.all.available}
        search={filter.search}
        onSearchChange={(val) => handleFilterChange({ search: val })}
      />

      {/* Semantic <nav> */}
      <FloorFilterNav
        filter={filter}
        onFilterChange={handleFilterChange}
        floorCounts={floorCounts}
      />

      {/* Semantic <main> */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        
        {/* Semantic <section>: Heatmap Overview */}
        <HeatmapStats
          desks={desks}
          onSelectZone={(zn) => handleFilterChange({ zone: zn })}
          activeZone={filter.zone}
        />

        {/* Semantic <section>: Desk Stations Directory */}
        <section id="desk-directory-section" aria-labelledby="directory-heading" className="space-y-6">
          
          {/* Section Toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-slate-300 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <h2 id="directory-heading" className="fluid-h2 text-slate-900 font-['Montserrat'] font-bold">
                  {filter.floor === 'all' ? 'All Building Sectors' : `${filter.floor} Floor Directory`}
                </h2>
                {filter.zone !== 'all' && (
                  <span className="px-3 py-1 rounded-full bg-[#1e293b] text-[#A0D4E0] text-xs font-mono font-bold">
                    {filter.zone}
                  </span>
                )}
              </div>
              <p className="fluid-body text-slate-600 text-sm mt-1">
                Showing <span className="font-bold text-slate-900 font-mono">{filteredDesks.length}</span> matching workspace units.
              </p>
            </div>

            {/* Active Filters Clear */}
            {(filter.floor !== 'all' || filter.zone !== 'all' || filter.onlyAvailable || filter.amenity !== 'all' || filter.search) && (
              <button
                onClick={handleResetFilters}
                className="self-start sm:self-auto px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 shadow-sm flex items-center gap-2 transition"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#A5856F]" />
                <span>Reset All Filters</span>
              </button>
            )}
          </div>

          {/* Responsive Grid Mandate:
              Mobile: Single-column list (grid-cols-1)
              Tablet (768px): 2x2 Grid (md:grid-cols-2)
              Desktop (1024px): 4x3 Grid (xl:grid-cols-4 / lg:grid-cols-3) */}
          {filteredDesks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredDesks.map((d) => (
                <DeskCard
                  key={d.id}
                  desk={d}
                  onCheckIn={(target) => setActiveCheckInDesk(target)}
                  onCheckOut={handleReleaseDesk}
                />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-300 max-w-2xl mx-auto my-12 shadow-sm">
              <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4 text-slate-400">
                <SlidersHorizontal className="w-8 h-8" />
              </div>
              <h3 className="font-['Montserrat'] font-bold text-xl text-slate-800">
                No Workspace Desks Found
              </h3>
              <p className="text-sm text-slate-500 mt-2 max-w-md mx-auto">
                No desks match your selected floor, zone, or availability criteria. Try switching floors or clearing filters.
              </p>
              <button
                onClick={handleResetFilters}
                className="mt-6 px-6 py-3 bg-[#A5856F] hover:bg-[#8e705b] text-white font-['Montserrat'] font-bold text-sm rounded-xl shadow-md transition"
              >
                Clear Filters
              </button>
            </div>
          )}

        </section>

      </main>

      {/* Semantic <footer> */}
      <Footer />

      {/* Modal Dialog */}
      {activeCheckInDesk && (
        <CheckInModal
          desk={activeCheckInDesk}
          onClose={() => setActiveCheckInDesk(null)}
          onConfirm={handleConfirmCheckin}
        />
      )}

    </div>
  );
}
